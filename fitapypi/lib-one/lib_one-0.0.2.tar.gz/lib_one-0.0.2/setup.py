# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['lib_one']

package_data = \
{'': ['*']}

install_requires = \
['numpy']

setup_kwargs = {
    'name': 'lib-one',
    'version': '0.0.2',
    'description': 'toy lib one',
    'long_description': None,
    'author': 'duyatfit',
    'author_email': 'pham@fitanalytics.com',
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=2.7,<3.0',
}


setup(**setup_kwargs)
