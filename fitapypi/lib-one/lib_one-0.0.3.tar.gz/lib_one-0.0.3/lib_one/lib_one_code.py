import numpy as np


def lib_one_hello():
    return 'lib one hello version 0.0.3'


def np_arange(i):
    return np.arange(i)
