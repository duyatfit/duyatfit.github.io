# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['lib_two']

package_data = \
{'': ['*']}

install_requires = \
['numpy>=1.14.0,<1.15.0']

entry_points = \
{'console_scripts': ['poetry = poetry.console:main']}

setup_kwargs = {
    'name': 'lib-two',
    'version': '0.0.1',
    'description': 'Lib two',
    'long_description': None,
    'author': 'Lib Two Author',
    'author_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=2.7, !=3.0.*, !=3.1.*, !=3.2.*, !=3.3.*',
}


setup(**setup_kwargs)
