def lib_two_hello():
    return 'lib two hello'
